#include <stdio.h>
#include <cstdlib>
#include <mpi.h>

#define TAG 0

int size;

int rank;


// Read size of matrix_a and matrix_b (n, m, l) and whole data of matrixes from stdin
//
// n_ptr:     pointer to n
// m_ptr:     pointer to m
// l_ptr:     pointer to l
// a_mat_ptr: pointer to matrix a (a should be a continuous memory space for placing n * m elements of int)
// b_mat_ptr: pointer to matrix b (b should be a continuous memory space for placing m * l elements of int)
void construct_matrices(int *n_ptr, int *m_ptr, int *l_ptr,
                        int **a_mat_ptr, int **b_mat_ptr)
{
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    if(rank == 0)
    {
        int num;
        scanf("%d %d %d", n_ptr, m_ptr, l_ptr);

        int n = *n_ptr, m = *m_ptr, l = *l_ptr;

        *a_mat_ptr = (int *)malloc(sizeof(int) * n * m);
        *b_mat_ptr = (int *)malloc(sizeof(int) * m * l);


        int *a_mat = *a_mat_ptr;
        int *b_mat = *b_mat_ptr;

        for(int i=0; i< n * m ; i++)
        {
            scanf("%d", &num);
            a_mat[i] = num;
        }

        for(int i=0; i< m * l ; i++)
        {
            scanf("%d", &num);
            b_mat[i] = num;
        }

        MPI_Bcast(n_ptr,1,MPI_INT,0,MPI_COMM_WORLD);
        MPI_Bcast(m_ptr,1,MPI_INT,0,MPI_COMM_WORLD);
        MPI_Bcast(l_ptr,1,MPI_INT,0,MPI_COMM_WORLD);
        MPI_Bcast(*a_mat_ptr, n * m,MPI_INT,0,MPI_COMM_WORLD);
        MPI_Bcast(*b_mat_ptr, m * l,MPI_INT,0,MPI_COMM_WORLD);

    } else
    {
        MPI_Bcast(n_ptr,1,MPI_INT,0,MPI_COMM_WORLD);
        MPI_Bcast(m_ptr,1,MPI_INT,0,MPI_COMM_WORLD);
        MPI_Bcast(l_ptr,1,MPI_INT,0,MPI_COMM_WORLD);
        int n = *n_ptr, m = *m_ptr, l = *l_ptr;
        *a_mat_ptr = (int *)malloc(sizeof(int) * n * m);
        *b_mat_ptr = (int *)malloc(sizeof(int) * m * l);
        MPI_Bcast(*a_mat_ptr, n * m,MPI_INT,0,MPI_COMM_WORLD);
        MPI_Bcast(*b_mat_ptr, m * l,MPI_INT,0,MPI_COMM_WORLD);
    }

}

// Just matrix multiplication (your should output the result in this function)
// 
// n:     row number of matrix a
// m:     col number of matrix a / row number of matrix b
// l:     col number of matrix b
// a_mat: a continuous memory placing n * m elements of int
// b_mat: a continuous memory placing m * l elements of int
void matrix_multiply(const int n, const int m, const int l,
                     const int *a_mat, const int *b_mat)
{
    int *b_mat_trans = (int *)malloc(sizeof(int) * l * m);
    #pragma omp parallel for collapse(2)
    for(int i = 0 ; i < l ; i++)
        for(int j = 0  ; j < m ; j++)
            b_mat_trans[i * m + j] = b_mat[j * l + i];
    if(rank == 0)
    {
        int *ans_mat = (int *)malloc(sizeof(int *) * n * l);
        
        int root_len = (n * l) / size;
        if((n * l) % size)
            root_len += 1;
        
        memset(ans_mat, 0, root_len*sizeof(int));

        /*int *(vec[root_len]);
        int count[root_len];
        for(int i=0 ; i<root_len ; i++)
        {
            count[i] = 0;
            vec[i] = (int *)malloc(sizeof(int) * m);
        }

        #pragma omp parallel
        for(int i=0 ; i<root_len ; i++)
        {
            int local = 0;
            #pragma omp for
            for(int j=0 ; j<m ; j++)
                local += a_mat[i / l * m + j] * b_mat[i % l + l*j];
            
            int index = __sync_fetch_and_add(&count[i], 1);
            vec[i][index] = local;
            
        }

        #pragma omp parallel for
        for(int i=0 ; i<root_len ; i++)
        {
            int local = 0;
            for(int j=0 ; j<count[i] ; j++)
                local += vec[i][j];
            ans_mat[i] = local;

            free(vec[i]);
        }*/

  
        #pragma omp parallel for
        for(int i=0 ; i<root_len ; i++)
        {
            for(int j=0 ; j<m ; j++)
                ans_mat[i] += a_mat[i / l * m + j] * b_mat_trans[(i % l)*m + j]; // b_mat[i % l + l*j]
            
        }

        
        int *recv = (int *)malloc(sizeof(int) * (n * l / size + 1));
        int len, start;
        for(int i=0; i<size-1 ; i++)
        {
            int node_rank = i+1;
            start = n * l / size * node_rank;
            if(i < (n * l) % size)
            {
                len = n * l / size + node_rank;
                start += node_rank;
            }
            else
            {
                len = n * l / size;
                start += (n * l) % size;
            }
            
            MPI_Status status;
            MPI_Recv(recv, len, MPI_INTEGER, node_rank, TAG, MPI_COMM_WORLD, &status);
            memcpy(ans_mat+start, recv, sizeof(int)*len);
            
        }
        
        free(recv);

        /*#pragma omp parallel for
        for(int i=0; i<size-1 ; i++)
        {
            int *recv = (int *)malloc(sizeof(int) * (n * l / size + 1));
            int len, start;
            int node_rank = i+1;
            start = n * l / size * node_rank;
            if(i < (n * l) % size)
            {
                len = n * l / size + node_rank;
                start += node_rank;
            }
            else
            {
                len = n * l / size;
                start += (n * l) % size;
            }

            int flag;
            while (1)
            {
                MPI_Iprobe(node_rank, TAG, MPI_COMM_WORLD, &flag, MPI_STATUS_IGNORE);

                if (flag == 1) break;
            }
            
            MPI_Status status;
            MPI_Recv(recv, len, MPI_INTEGER, node_rank, TAG, MPI_COMM_WORLD, &status);
            memcpy(ans_mat+start, recv, sizeof(int)*len);

            free(recv);
            
        }*/
        

        /*int *(recv[size-1]);
        int len[size-1];
        int start[size-1];

        MPI_Request requests[size-1];
        MPI_Status status[size-1];

        
        for(int i=0; i<size-1 ; i++)
        {
            int node_rank = i+1;
            start[i] = n * l / size * node_rank;
            if(i < (n * l) % size)
            {
                len[i] = n * l / size + node_rank;
                start[i] += node_rank;
            }
            else
            {
                len[i] = n * l / size;
                start[i] += (n * l) % size;
            }
            recv[i] = (int *)malloc(sizeof(int) * len[i]);
                
            MPI_Irecv(recv[i], len[i], MPI_INTEGER, node_rank, TAG, MPI_COMM_WORLD, &requests[i]);
            
        }        

        MPI_Waitall(size-1, requests, status);

        #pragma omp parallel
        for(int i=0; i<size-1 ; i++)
        {
            #pragma omp for
            for(int j = 0 ; j<len[i] ; j++)
                ans_mat[start[i]+j] = recv[i][j];
            
        }

        #pragma omp parallel for
        for(int i=0; i<size-1 ; i++)
            free(recv[i]);*/
        

        for(int i=0 ; i<n*l ; i++)
        {
            printf("%d ",ans_mat[i]);
            if((i+1)%l==0)
                printf("\n");

        }
            
        free(ans_mat);
    } else
    {
        int *ans_local;
        int len;
        int start = n * l / size * rank;
        if(rank < (n * l) % size)
        {
            len = n * l / size + 1;
            start += rank;
        }
        else
        {
            len = n * l / size;
            start += (n * l) % size;
        }
        
        ans_local = (int *)malloc(sizeof(int) * len);
        
        memset(ans_local, 0, len*sizeof(int));

        /*int *(vec[len]);
        int count[len];
        for(int i=0 ; i<len ; i++)
        {
            count[i] = 0;
            vec[i] = (int *)malloc(sizeof(int) * m);
        }
        
        #pragma omp parallel
        for(int i=0 ; i<len ; i++)
        {
            int local = 0;
            #pragma omp for
            for(int j=0 ; j<m ; j++)
                local += a_mat[(start+i) / l * m + j] * b_mat[(start+i) % l + l*j];
            
            int index = __sync_fetch_and_add(&count[i], 1);
            vec[i][index] = local;
            
        }

        #pragma omp parallel for
        for(int i=0 ; i<len ; i++)
        {
            int local = 0;
            for(int j=0 ; j<count[i] ; j++)
                local += vec[i][j];
            ans_local[i] = local;

            free(vec[i]);
        }*/

        #pragma omp parallel for
        for(int i=0 ; i<len ; i++)
        {
            for(int j=0 ; j<m ; j++)
                ans_local[i] += a_mat[(start+i) / l * m + j] * b_mat_trans[((start+i) % l)*m + j]; // b_mat[(start+i) % l + l*j]
            
        }


        // MPI_Request request;
        // MPI_Status status;

        // MPI_Isend(ans_local, len, MPI_INTEGER, 0, TAG, MPI_COMM_WORLD, &request);
        // MPI_Waitall(1, &request, &status);

        MPI_Send(ans_local, len, MPI_INTEGER, 0, TAG, MPI_COMM_WORLD);
        free(ans_local);
    }

    free(b_mat_trans);

}

// Remember to release your allocated memory
void destruct_matrices(int *a_mat, int *b_mat)
{
    free(a_mat);
    free(b_mat);
}